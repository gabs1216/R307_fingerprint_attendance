﻿Imports System.Data.SqlClient


Public Class Form1

    Dim dbfile As String = System.Environment.CurrentDirectory + "\Attendance_System.xlsx"
    Dim con As String = "provider=Microsoft.Ace.OLEDB.12.0;Data Source='" & dbfile & "';Extended Properties=Excel 8.0;"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        getSerialPortNames()
        loadExcelDb()
    End Sub

    Sub getSerialPortNames()
        For Each sp As String In My.Computer.Ports.SerialPortNames
            serialPort.Items.Add(sp)
        Next
    End Sub


    Sub sendATcommand(ByVal ATcommand As String)
        Try
            If serialPort.Text <> "<select port>" Then
                If SerialPort1.IsOpen = False Then
                    SerialPort1.Open()
                End If
                str1 = ""
                SerialPort1.Write(ATcommand & vbCrLf)
            Else
                MsgBox("Select port first!",, "Gabriele Ramos Hobbyist Page")
            End If
        Catch ex As Exception
            MsgBox(ex.Message,, "Gabriele Ramos Hobbyist Page")
        End Try
    End Sub

    Sub sendMessage(ByVal msg As String)
        sendATcommand(msg)
    End Sub

    Function convertToDate(ByVal sdatetime As String) As DateTime
        Try
            'sdatetime ' "2019-03-03 12:00 PM"
            Dim convertedDate As DateTime = DateTime.ParseExact(sdatetime, "yyyy-MM-dd HH:mm tt", Nothing)
            Return convertedDate
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Function



    Private Sub serialPort_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles serialPort.SelectedIndexChanged
        Try
            If SerialPort1.IsOpen Then
                SerialPort1.Close()
            End If
            With SerialPort1
                .PortName = serialPort.Text
                .BaudRate = CInt(baudRate.Text) 'convert to integer
                .Parity = IO.Ports.Parity.None
                .DataBits = 8
                .StopBits = IO.Ports.StopBits.One
                .Open()
            End With

            ToolStripStatusLabel1.Text = "Connected on: " & serialPort.Text & "     Baud Rate: " & baudRate.Text
        Catch ex As Exception

        End Try
        SelectPortToolStripMenuItem.HideDropDown()
    End Sub

    Dim str As String = ""
    Dim str1 As String = ""
    Private Sub SerialPort1_DataReceived(ByVal sender As System.Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        str = SerialPort1.ReadExisting()
        Invoke(Dm, str)
    End Sub

    Delegate Sub myDelegateMethod(ByVal text As String)
    Dim Dm As New myDelegateMethod(AddressOf serialReadBack)

    Dim indno As String = ""
    Sub serialReadBack(ByVal sString As String)
        On Error Resume Next
        RichTextBox1.AppendText(str)
        If str.Contains("Found ID #") Then
            RichTextBox1.Clear()
            Dim sidarr As String() = str.Split(" ")
            Dim sid As String = sidarr(2)
            sid = sid.Remove(0, 1)
            Dim studentrecord As String() = readExcelDbRecord(sid).Split(",")
            Dim bnorecord As Boolean = False
            If studentrecord(0) = "" And studentrecord(1) = "" Then
                bnorecord = True
            End If
            If bnorecord = False Then
                If studentrecord(0) = "" Then
                    updateRecord(sid, "Date Time", Now)
                    Label9.Text = studentrecord(1)
                    Label8.Text = studentrecord(2)
                    Label7.Text = studentrecord(3)
                Else
                    MsgBox("You already recorded your Time-IN." & vbCrLf & vbCrLf & " The actual time stamp is " & studentrecord(0),, "Finger print database")
                    Label10.Text = studentrecord(0)
                    Label9.Text = studentrecord(1)
                    Label8.Text = studentrecord(2)
                    Label7.Text = studentrecord(3)
                End If
            Else
                MsgBox("New student! Kindly enroll him/her first on in this database...",, "Finger print database")
                TextBox4.Text = sid
                TextBox4.ReadOnly = True
            End If
            RichTextBox1.Text = str
        End If
    End Sub




    Private Sub ClosePortToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClosePortToolStripMenuItem.Click
        SerialPort1.Close()
        serialPort.Text = "<select port>"
        ToolStripStatusLabel1.Text = "Disconnected..."
    End Sub

    Private Sub BaudRate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles baudRate.SelectedIndexChanged
        BaudRateToolStripMenuItem.HideDropDown()
    End Sub

    Private Sub ArduinoCodeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ArduinoCodeToolStripMenuItem.Click
        MsgBox("Use the Adafruit ""fingerprint"" sample sketch to make this program work!" & vbCrLf & "Also use the Adafruit ""enroll"" sample sketch in order to generate Fingerprint ID",, "Finger print database")
    End Sub

    Sub loadExcelDb()
        Dim cn As OleDb.OleDbConnection
        Try
            cn = New OleDb.OleDbConnection(con)
            Dim cmd As OleDb.OleDbDataAdapter = New OleDb.OleDbDataAdapter("select * from [Attendance$]", cn)
            cmd.TableMappings.Add("Table", "Gabriele Ramos hobbyist page")
            Dim ds As DataSet = New DataSet
            cmd.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            cn.Close()
        Catch ex As Exception
            cn.Close()
        End Try

    End Sub

    Function readExcelDbRecord(ByVal sid As String) As String
        Dim cn As OleDb.OleDbConnection
        readExcelDbRecord = ",,,"
        Try
            cn = New OleDb.OleDbConnection(con)
            Dim cmd As OleDb.OleDbCommand = New OleDb.OleDbCommand("select * from [Attendance$] where [Finger ID]='" & sid & "'", cn)
            If cn.State = ConnectionState.Closed Then cn.Open()
            Dim dr As OleDb.OleDbDataReader = cmd.ExecuteReader
            While dr.Read
                readExcelDbRecord = dr.Item("Date Time") & "," & dr.Item("Last Name") & "," & dr.Item("First Name") & "," & dr.Item("Middle Name")
                Exit While
            End While
            cn.Close()
            Return readExcelDbRecord
        Catch ex As Exception
            cn.Close()
            '       MsgBox("Update Failed! Contact your software developer.",, "Finger print database")
            Return readExcelDbRecord
        End Try
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        insertRecord(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text)
    End Sub

    Sub insertRecord(ByVal ln As String, ByVal fn As String, ByVal mn As String, ByVal fid As String)
        Dim cn As OleDb.OleDbConnection
        Dim cmd As New OleDb.OleDbCommand
        Dim sql As String
        Try
            cn = New OleDb.OleDbConnection(con)
            cn.Open()
            cmd.Connection = cn
            sql = "Insert into [Attendance$] ([Finger ID],[Last Name],[First Name],[Middle Name]) values(" & fid & ",'" & ln.ToUpper & "','" & fn.ToUpper & "','" & mn.ToUpper & "')"
            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
            cn.Close()
            MsgBox("New Student Successfuly Added ")

            For Each ctrl As Control In GroupBox2.Controls
                If TypeOf ctrl Is TextBox Then
                    ctrl.Text = ""
                End If
            Next
        Catch ex As Exception
            cn.Close()
            '   MsgBox(ex.ToString)
            MsgBox("Update Failed! Contact your software developer.",, "Finger print database")
        End Try
        loadExcelDb()
    End Sub

    Sub updateRecord(ByVal sid As String, ByVal sfield As String, ByVal val As String)
        Dim cn As OleDb.OleDbConnection
        Dim cmd As New OleDb.OleDbCommand
        Dim sql As String
        Try
            cn = New OleDb.OleDbConnection(con)
            cn.Open()
            cmd.Connection = cn
            sql = "Update [Attendance$] Set [" & sfield & "]='" & val.ToUpper & "' Where [Finger ID]='" & sid & "'"
            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
            cn.Close()
            MsgBox("Update successful!")
            Label10.Text = val
            '    sendMessage("SEND MESSAGE:" + "Student Name: " + Label9.Text + ", " + Label8.Text + " " + Label7.Text + " Actual Time-IN: " + Label10.Text)
        Catch ex As Exception
            cn.Close()
            '   MsgBox(ex.ToString)
            MsgBox("Update Failed! Contact your software developer.",, "Finger print database")
        End Try
        loadExcelDb()
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ClosePortToolStripMenuItem.PerformClick()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        If MsgBox("This process will close the program in order to give way to excel application. Would you like to continue?", MessageBoxButtons.YesNo, "Finger print database") = MsgBoxResult.Yes Then
            Process.Start(dbfile)
            Close()
        End If
    End Sub
End Class
